

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Booking
 */
@WebServlet("/Booking")
public class Booking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Booking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();

		//String booking_id=request.getParameter("booking_id");
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		
		
		String city=request.getParameter("city");
		String pdate=request.getParameter("pdate");
		String ptime=request.getParameter("ptime");
		String address=request.getParameter("address");
		String dter=request.getParameter("dter");
		String rdate=request.getParameter("rdate");
		String ater=request.getParameter("ater");
		String jtype=request.getParameter("jtype");
		String no_of_pas=request.getParameter("no_of_pas");
		String cseat=request.getParameter("cseat");
		String mesg=request.getParameter("mesg");
		
	try
	{
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/emp","root","kavi1234");
	String qr="insert into booking values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	PreparedStatement ps=con.prepareStatement(qr);
	
		
	ps.setString(1,name);
	ps.setString(2,email);
	ps.setString(3,mobile);
	ps.setString(4,city);
	ps.setString(5,pdate);
	ps.setString(6,ptime);
	ps.setString(7,address);
	ps.setString(8,dter);
	ps.setString(9,rdate);
	ps.setString(10,ater);
	ps.setString(11,jtype);
	ps.setString(12,no_of_pas);
	ps.setString(13,cseat);
	ps.setString(14,mesg);

	
	int i=ps.executeUpdate();
	if(i>0)
	{
		response.sendRedirect("confirm.jsp");
		HttpSession session=request.getSession();
		session.setAttribute("name",name);
		session.setMaxInactiveInterval(30);
		out.println("Your booking request is made successfully.....");
		
		
		
	
	}else
	{
		
		
		
		out.println("Your booking request is not made.....");
	}
	con.close();

	}catch(Exception e)
	{
	 out.println(e);
	}

	}

}
