

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Uhome
 */
@WebServlet("/Uhome")
public class Uhome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Uhome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<body bgcolor=#0a2f5b>");
		out.println("<h1 align=center><font color=white>WELCOME TO THE ADMIN MODULE OF THE WEBSITE</font></h1>");
		//HttpSession session=request.getSession();
		//String email=(String) session.getAttribute("uid");
		
		out.println("<a href=add.html><font color=yellow size=6>Add</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		out.println("<a href=del.html><font color=yellow size=6>Delete</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		out.println("<a href=up.html><font color=yellow size=6>Update</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		out.println("<a href=Show><font color=yellow size=6>Show</font></a>");
		out.println("<br/>");
		out.println("<h1 align=center><font color=white size=6>SHOW BOOKINGS</font></h1>");
		out.println("<center><a href=ShowBookings.jsp><font color=yellow size=6>Go to Bookings</font></a></center>");
		out.println("<br/>");
		out.println("<h1 align=center><font color=white size=6>SHOW LOGIN USERS</font></h1>");
		out.println("<center><a href=Showuser><font color=yellow size=6>Go to Logins</font></a></center>");
		out.println("<br/>");
		out.println("</body>");

	}

}
